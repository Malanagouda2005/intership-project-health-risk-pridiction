'use client'

import { useState } from 'react'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { X } from 'lucide-react'

const COMMON_SYMPTOMS = [
  'Fever',
  'Headache',
  'Fatigue',
  'Chest Pain',
  'Shortness of Breath',
  'Cough',
  'Nausea',
  'Dizziness',
  'Body Aches',
  'Sore Throat',
]

interface SymptomsSelectorProps {
  symptoms: string[]
  onChange: (symptoms: string[]) => void
}

export function SymptomsSelector({ symptoms, onChange }: SymptomsSelectorProps) {
  const [customSymptom, setCustomSymptom] = useState('')
  const [showCustomInput, setShowCustomInput] = useState(false)

  const toggleSymptom = (symptom: string) => {
    if (symptoms.includes(symptom)) {
      onChange(symptoms.filter((s) => s !== symptom))
    } else {
      onChange([...symptoms, symptom])
    }
  }

  const addCustomSymptom = () => {
    if (customSymptom.trim() && !symptoms.includes(customSymptom)) {
      onChange([...symptoms, customSymptom])
      setCustomSymptom('')
      setShowCustomInput(false)
    }
  }

  const removeCustomSymptom = (symptom: string) => {
    if (!COMMON_SYMPTOMS.includes(symptom)) {
      onChange(symptoms.filter((s) => s !== symptom))
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {COMMON_SYMPTOMS.map((symptom) => (
          <div key={symptom} className="flex items-center space-x-2">
            <Checkbox
              id={symptom}
              checked={symptoms.includes(symptom)}
              onCheckedChange={() => toggleSymptom(symptom)}
            />
            <Label htmlFor={symptom} className="cursor-pointer font-normal">
              {symptom}
            </Label>
          </div>
        ))}
      </div>

      {/* Custom Symptoms */}
      <div className="space-y-3 border-t border-border pt-4">
        <div className="flex flex-wrap gap-2">
          {symptoms
            .filter((s) => !COMMON_SYMPTOMS.includes(s))
            .map((symptom) => (
              <div
                key={symptom}
                className="flex items-center gap-2 rounded-full bg-secondary/20 px-3 py-1 text-sm text-foreground"
              >
                {symptom}
                <button
                  onClick={() => removeCustomSymptom(symptom)}
                  className="hover:text-destructive"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
        </div>

        {showCustomInput ? (
          <div className="flex gap-2">
            <Input
              placeholder="Enter custom symptom"
              value={customSymptom}
              onChange={(e) => setCustomSymptom(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addCustomSymptom()}
              autoFocus
            />
            <Button onClick={addCustomSymptom} size="sm" className="bg-secondary">
              Add
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowCustomInput(true)}
            className="text-secondary"
          >
            + Add Custom Symptom
          </Button>
        )}
      </div>
    </div>
  )
}
