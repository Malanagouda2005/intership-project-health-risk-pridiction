'use client'

import { Loader2 } from 'lucide-react'

interface LoaderProps {
  isLoading: boolean
  message?: string
}

export function Loader({ isLoading, message = 'Processing...' }: LoaderProps) {
  if (!isLoading) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="rounded-lg bg-white p-8 text-center shadow-2xl dark:bg-slate-900">
        <Loader2 className="mx-auto h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 font-semibold text-foreground">{message}</p>
        <p className="mt-2 text-sm text-muted-foreground">Analyzing your health data...</p>
      </div>
    </div>
  )
}
