'use client'

import { AlertCircle, CheckCircle, AlertTriangle, Heart } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface HealthRiskResult {
  riskLevel: 'Low' | 'Medium' | 'High'
  riskPercentage: number
  detectedConditions: string[]
  recommendations: string[]
  bmi: number
}

interface ResultCardProps {
  result: HealthRiskResult | null
  isLoading: boolean
}

export function ResultCard({ result, isLoading }: ResultCardProps) {
  if (isLoading) {
    return (
      <Card className="h-full border-border bg-white dark:bg-slate-900">
        <CardHeader className="space-y-2">
          <CardTitle>Analysis Results</CardTitle>
          <CardDescription>Processing your health data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-8 animate-pulse rounded-lg bg-muted"></div>
            <div className="h-12 animate-pulse rounded-lg bg-muted"></div>
            <div className="h-20 animate-pulse rounded-lg bg-muted"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!result) {
    return (
      <Card className="flex h-full items-center justify-center border-border bg-white dark:bg-slate-900">
        <CardContent className="text-center">
          <Heart className="mx-auto h-16 w-16 text-muted-foreground/40" />
          <p className="mt-4 text-lg font-semibold text-foreground">No results yet</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Fill in your health data and click &quot;Predict Risk&quot; to get started
          </p>
        </CardContent>
      </Card>
    )
  }

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low':
        return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950'
      case 'Medium':
        return 'text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950'
      case 'High':
        return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950'
      default:
        return 'text-gray-600 bg-gray-50'
    }
  }

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'Low':
        return <CheckCircle className="h-8 w-8" />
      case 'Medium':
        return <AlertTriangle className="h-8 w-8" />
      case 'High':
        return <AlertCircle className="h-8 w-8" />
      default:
        return <Heart className="h-8 w-8" />
    }
  }

  return (
    <Card className="border-border bg-white dark:bg-slate-900">
      <CardHeader>
        <CardTitle>Health Risk Assessment</CardTitle>
        <CardDescription>Based on your provided health data</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Risk Level */}
        <div className={`rounded-lg p-6 ${getRiskColor(result.riskLevel)}`}>
          <div className="flex items-center gap-3">
            {getRiskIcon(result.riskLevel)}
            <div>
              <p className="font-semibold">Risk Level: {result.riskLevel}</p>
              <p className="text-sm font-medium">{result.riskPercentage}% Risk</p>
            </div>
          </div>
        </div>

        {/* Risk Percentage Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-medium text-foreground">Risk Score</span>
            <span className="font-semibold text-primary">{result.riskPercentage}%</span>
          </div>
          <div className="h-3 overflow-hidden rounded-full bg-muted">
            <div
              className={`h-full transition-all ${
                result.riskPercentage < 40
                  ? 'bg-green-500'
                  : result.riskPercentage < 70
                    ? 'bg-yellow-500'
                    : 'bg-red-500'
              }`}
              style={{ width: `${result.riskPercentage}%` }}
            />
          </div>
        </div>

        {/* BMI */}
        <div className="rounded-lg border border-border bg-muted/50 p-4">
          <p className="text-sm font-medium text-muted-foreground">BMI</p>
          <p className="mt-1 text-2xl font-bold text-primary">{result.bmi.toFixed(1)}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {result.bmi < 18.5
              ? 'Underweight'
              : result.bmi < 25
                ? 'Normal weight'
                : result.bmi < 30
                  ? 'Overweight'
                  : 'Obese'}
          </p>
        </div>

        {/* Detected Conditions */}
        {result.detectedConditions.length > 0 && (
          <div className="space-y-2">
            <p className="font-semibold text-foreground">Detected Conditions:</p>
            <div className="space-y-2">
              {result.detectedConditions.map((condition, idx) => (
                <div
                  key={idx}
                  className="rounded-lg border-l-4 border-destructive bg-destructive/10 px-4 py-2 text-sm text-destructive dark:text-destructive"
                >
                  {condition}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recommendations */}
        <div className="space-y-2">
          <p className="font-semibold text-foreground">Recommendations:</p>
          <div className="space-y-2">
            {result.recommendations.map((rec, idx) => (
              <div
                key={idx}
                className="flex gap-3 rounded-lg border border-border bg-muted/50 p-3"
              >
                <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-white">
                  {idx + 1}
                </span>
                <p className="text-sm text-foreground">{rec}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-3 text-xs text-yellow-800 dark:border-yellow-900 dark:bg-yellow-950 dark:text-yellow-200">
          ⚠️ This assessment is for informational purposes only. Please consult with a qualified
          healthcare professional for medical advice.
        </div>
      </CardContent>
    </Card>
  )
}
