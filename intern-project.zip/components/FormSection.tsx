'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { SymptomsSelector } from './SymptomsSelector'
import { ImageUpload } from './ImageUpload'
import { User, Activity, Droplet, Zap, FileText } from 'lucide-react'

interface FormData {
  name: string
  age: string
  gender: string
  height: string
  weight: string
  bloodPressure: string
  glucoseLevel: string
  heartRate: string
  symptoms: string[]
  smoking: boolean
  alcohol: boolean
  exercise: boolean
  image: File | null
}

interface FormSectionProps {
  onSubmit: (data: FormData) => void
  isLoading: boolean
}

export function FormSection({ onSubmit, isLoading }: FormSectionProps) {
  const [form, setForm] = useState<FormData>({
    name: '',
    age: '',
    gender: '',
    height: '',
    weight: '',
    bloodPressure: '',
    glucoseLevel: '',
    heartRate: '',
    symptoms: [],
    smoking: false,
    alcohol: false,
    exercise: false,
    image: null,
  })

  const [preview, setPreview] = useState<string | null>(null)

  const bmi =
    form.height && form.weight
      ? (parseFloat(form.weight) / (parseFloat(form.height) / 100) ** 2).toFixed(1)
      : null

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setForm((prev) => ({ ...prev, gender: value }))
  }

  const handleToggle = (field: 'smoking' | 'alcohol' | 'exercise') => {
    setForm((prev) => ({ ...prev, [field]: !prev[field] }))
  }

  const handleImageChange = (file: File | null) => {
    setForm((prev) => ({ ...prev, image: file }))
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    } else {
      setPreview(null)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.age || !form.gender || !form.height || !form.weight) {
      alert('Please fill in all required fields')
      return
    }
    onSubmit(form)
  }

  return (
    <Card className="h-full border-border bg-white dark:bg-slate-900">
      <CardHeader className="border-b border-border">
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-secondary" />
          Health Assessment
        </CardTitle>
        <CardDescription>Provide your health information for risk prediction</CardDescription>
      </CardHeader>

      <CardContent className="overflow-y-auto">
        <form onSubmit={handleSubmit} className="space-y-6 pt-6">
          {/* Basic Details Section */}
          <section className="space-y-4">
            <h3 className="flex items-center gap-2 font-semibold text-foreground">
              <User className="h-4 w-4 text-secondary" />
              Basic Details
            </h3>

            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium">
                Full Name *
              </Label>
              <Input
                id="name"
                name="name"
                value={form.name}
                onChange={handleInputChange}
                placeholder="John Doe"
                className="border-border"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="age" className="text-sm font-medium">
                  Age (years) *
                </Label>
                <Input
                  id="age"
                  name="age"
                  type="number"
                  value={form.age}
                  onChange={handleInputChange}
                  placeholder="30"
                  min="0"
                  max="120"
                  className="border-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="gender" className="text-sm font-medium">
                  Gender *
                </Label>
                <Select value={form.gender} onValueChange={handleSelectChange}>
                  <SelectTrigger className="border-border">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </section>

          {/* Body Metrics Section */}
          <section className="space-y-4 border-t border-border pt-4">
            <h3 className="flex items-center gap-2 font-semibold text-foreground">
              <Activity className="h-4 w-4 text-secondary" />
              Body Metrics
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="height" className="text-sm font-medium">
                  Height (cm) *
                </Label>
                <Input
                  id="height"
                  name="height"
                  type="number"
                  value={form.height}
                  onChange={handleInputChange}
                  placeholder="175"
                  min="0"
                  className="border-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight" className="text-sm font-medium">
                  Weight (kg) *
                </Label>
                <Input
                  id="weight"
                  name="weight"
                  type="number"
                  value={form.weight}
                  onChange={handleInputChange}
                  placeholder="70"
                  min="0"
                  className="border-border"
                />
              </div>
            </div>

            {/* BMI Display */}
            {bmi && (
              <div className="rounded-lg bg-primary/10 p-4">
                <p className="text-xs text-muted-foreground">Body Mass Index (BMI)</p>
                <p className="text-2xl font-bold text-primary">{bmi}</p>
                <p className="text-xs text-muted-foreground">
                  {parseFloat(bmi) < 18.5
                    ? 'Underweight'
                    : parseFloat(bmi) < 25
                      ? 'Normal weight'
                      : parseFloat(bmi) < 30
                        ? 'Overweight'
                        : 'Obese'}
                </p>
              </div>
            )}
          </section>

          {/* Medical Data Section */}
          <section className="space-y-4 border-t border-border pt-4">
            <h3 className="flex items-center gap-2 font-semibold text-foreground">
              <Droplet className="h-4 w-4 text-secondary" />
              Medical Data
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bloodPressure" className="text-sm font-medium">
                  Blood Pressure
                </Label>
                <Input
                  id="bloodPressure"
                  name="bloodPressure"
                  value={form.bloodPressure}
                  onChange={handleInputChange}
                  placeholder="120/80"
                  className="border-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="glucoseLevel" className="text-sm font-medium">
                  Glucose Level
                </Label>
                <Input
                  id="glucoseLevel"
                  name="glucoseLevel"
                  type="number"
                  value={form.glucoseLevel}
                  onChange={handleInputChange}
                  placeholder="100"
                  min="0"
                  className="border-border"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="heartRate" className="text-sm font-medium">
                Heart Rate (optional, bpm)
              </Label>
              <Input
                id="heartRate"
                name="heartRate"
                type="number"
                value={form.heartRate}
                onChange={handleInputChange}
                placeholder="72"
                min="0"
                className="border-border"
              />
            </div>
          </section>

          {/* Symptoms Section */}
          <section className="space-y-4 border-t border-border pt-4">
            <h3 className="font-semibold text-foreground">Symptoms</h3>
            <SymptomsSelector
              symptoms={form.symptoms}
              onChange={(symptoms) => setForm((prev) => ({ ...prev, symptoms }))}
            />
          </section>

          {/* Lifestyle Section */}
          <section className="space-y-4 border-t border-border pt-4">
            <h3 className="font-semibold text-foreground">Lifestyle Factors</h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border border-border p-3">
                <Label htmlFor="smoking" className="cursor-pointer font-normal">
                  Smoking
                </Label>
                <Switch
                  id="smoking"
                  checked={form.smoking}
                  onCheckedChange={() => handleToggle('smoking')}
                />
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border p-3">
                <Label htmlFor="alcohol" className="cursor-pointer font-normal">
                  Alcohol Consumption
                </Label>
                <Switch
                  id="alcohol"
                  checked={form.alcohol}
                  onCheckedChange={() => handleToggle('alcohol')}
                />
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border p-3">
                <Label htmlFor="exercise" className="cursor-pointer font-normal">
                  Regular Exercise
                </Label>
                <Switch
                  id="exercise"
                  checked={form.exercise}
                  onCheckedChange={() => handleToggle('exercise')}
                />
              </div>
            </div>
          </section>

          {/* Medical Image Upload */}
          <section className="space-y-4 border-t border-border pt-4">
            <h3 className="flex items-center gap-2 font-semibold text-foreground">
              <FileText className="h-4 w-4 text-secondary" />
              Medical Image (Optional)
            </h3>
            <ImageUpload image={form.image} preview={preview} onChange={handleImageChange} />
          </section>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-primary to-secondary py-6 text-base font-semibold text-white hover:opacity-90"
          >
            {isLoading ? 'Analyzing...' : 'Predict Risk'}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
