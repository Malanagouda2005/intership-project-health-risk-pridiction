# Architecture Guide - HealthRisk AI

A detailed breakdown of the application's structure, data flow, and component relationships.

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Browser / Client                      │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌─────────────────────────────────────────────────┐   │
│  │              Next.js App Router                  │   │
│  ├─────────────────────────────────────────────────┤   │
│  │                                                  │   │
│  │  ┌──────────────────────────────────────────┐  │   │
│  │  │   Root Layout (layout.tsx)                │  │   │
│  │  │   ├─ ThemeProvider (next-themes)         │  │   │
│  │  │   ├─ Global Styles (globals.css)        │  │   │
│  │  │   └─ Metadata & Viewport                │  │   │
│  │  └──────────────────────────────────────────┘  │   │
│  │                                                  │   │
│  │  ┌──────────────────────────────────────────┐  │   │
│  │  │   Main Page (page.tsx)                    │  │   │
│  │  │   ├─ Navbar Component                    │  │   │
│  │  │   ├─ FormSection Component               │  │   │
│  │  │   ├─ ResultCard Component                │  │   │
│  │  │   └─ Loader Component                    │  │   │
│  │  └──────────────────────────────────────────┘  │   │
│  │                                                  │   │
│  │  ┌──────────────────────────────────────────┐  │   │
│  │  │   useHealthForm Hook                      │  │   │
│  │  │   ├─ Risk Calculation Logic               │  │   │
│  │  │   ├─ Form Submission                      │  │   │
│  │  │   └─ State Management                     │  │   │
│  │  └──────────────────────────────────────────┘  │   │
│  │                                                  │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
└─────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────┐
│                   Server-Side                            │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────────────────────────────────┐           │
│  │   API Routes (app/api/predict/route.ts)   │           │
│  │   ├─ POST /api/predict                    │           │
│  │   └─ Risk Prediction Logic                │           │
│  └──────────────────────────────────────────┘           │
│                                                           │
│  (Optional: Backend ML Service)                         │
│                                                           │
└─────────────────────────────────────────────────────────┘
```

## 📊 Component Hierarchy

```
App (Page)
│
├── Navbar
│   ├── App Title
│   ├── Logo (Heart Icon)
│   └── Theme Toggle Button
│
├── Container (Main Content)
│   │
│   ├── FormSection (Left Panel)
│   │   ├── Basic Details Section
│   │   │   ├── Name Input
│   │   │   ├── Age Input
│   │   │   └── Gender Select
│   │   │
│   │   ├── Body Metrics Section
│   │   │   ├── Height Input
│   │   │   ├── Weight Input
│   │   │   └── BMI Display (Auto-calculated)
│   │   │
│   │   ├── Medical Data Section
│   │   │   ├── Blood Pressure Input
│   │   │   ├── Glucose Level Input
│   │   │   └── Heart Rate Input
│   │   │
│   │   ├── Symptoms Section
│   │   │   └── SymptomsSelector Component
│   │   │       ├── Common Symptoms Checkboxes
│   │   │       └── Custom Symptom Input
│   │   │
│   │   ├── Lifestyle Section
│   │   │   ├── Smoking Toggle
│   │   │   ├── Alcohol Toggle
│   │   │   └── Exercise Toggle
│   │   │
│   │   ├── Medical Image Section
│   │   │   └── ImageUpload Component
│   │   │       ├── Drag & Drop Area
│   │   │       ├── File Input
│   │   │       └── Image Preview
│   │   │
│   │   └── Submit Button
│   │
│   └── ResultCard (Right Panel)
│       ├── Risk Level Display
│       ├── Risk Percentage Bar
│       ├── BMI Category
│       ├── Detected Conditions
│       ├── Recommendations
│       └── Medical Disclaimer
│
├── Loader (Overlay)
│   ├── Loading Spinner
│   └── Status Message
│
└── Footer
    └── Copyright & Disclaimer
```

## 🔄 Data Flow Diagram

```
User Input
    ↓
FormSection.handleSubmit()
    ↓
Validation Check
    ├─ If Invalid → Show Error Alert
    └─ If Valid ↓
      ↓
page.handleFormSubmit()
    ↓
useHealthForm.submitForm()
    ├─ Set Loading: true
    ├─ Show Loader Component
    └─ ↓
      ↓
Risk Calculation
├─ Option 1: Client-side (calculateRisk())
│   ├─ Parse form data
│   ├─ Calculate risk score (0-99)
│   ├─ Detect conditions
│   └─ Generate recommendations
│   └─ ↓
└─ Option 2: Backend API
    ├─ POST /api/predict
    ├─ Send form data
    ├─ Receive result
    └─ ↓
      ↓
Result Processing
    ├─ Set Loading: false
    ├─ Set Result State
    └─ Hide Loader Component
      ↓
ResultCard Component
    ├─ Display Risk Level (Low/Medium/High)
    ├─ Display Risk Percentage (0-99%)
    ├─ Display Conditions
    ├─ Display Recommendations
    └─ Show Medical Disclaimer
      ↓
User Views Results
    ├─ Can submit new form
    └─ Can change inputs
```

## 📦 File Structure with Descriptions

```
health-risk-predictor/
│
├── app/
│   ├── page.tsx (71 lines)
│   │   └─ Main dashboard page
│   │      - Imports: Navbar, FormSection, ResultCard, Loader, useHealthForm
│   │      - Manages form submission and results display
│   │      - Handles responsive layout (mobile vs desktop)
│   │      - Scroll to results on desktop
│   │
│   ├── layout.tsx (51 lines)
│   │   └─ Root layout component
│   │      - Imports fonts (Geist)
│   │      - Configures metadata & viewport
│   │      - Sets up ThemeProvider for dark mode
│   │      - Wraps all children with theme context
│   │
│   ├── globals.css (100+ lines)
│   │   └─ Global styles and CSS custom properties
│   │      - Light theme color variables
│   │      - Dark theme color variables
│   │      - Tailwind configuration
│   │      - Design tokens (primary, secondary, etc.)
│   │
│   ├── api/
│   │   └── predict/
│   │       └── route.ts (207 lines)
│   │           └─ API endpoint for health prediction
│   │              - POST handler
│   │              - Input validation
│   │              - Risk calculation (example)
│   │              - Error handling
│   │
│   └── favicon.ico
│
├── components/
│   ├── Navbar.tsx (62 lines)
│   │   └─ Top navigation bar
│   │      - App title and logo (Heart icon)
│   │      - Dark mode toggle button
│   │      - Uses next-themes for theme switching
│   │      - Sticky positioning
│   │
│   ├── FormSection.tsx (355 lines)
│   │   └─ Main health data input form
│   │      - Manages form state (name, age, gender, etc.)
│   │      - Basic details section
│   │      - Body metrics with live BMI calculation
│   │      - Medical data inputs (BP, glucose, HR)
│   │      - Form validation on submit
│   │      - Imports SymptomsSelector & ImageUpload
│   │
│   ├── ResultCard.tsx (175 lines)
│   │   └─ Results display component
│   │      - Shows risk level with color coding
│   │      - Risk percentage with progress bar
│   │      - BMI categorization
│   │      - Detected conditions list
│   │      - Personalized recommendations
│   │      - Medical disclaimer
│   │      - Loading skeleton state
│   │      - Empty state message
│   │
│   ├── SymptomsSelector.tsx (119 lines)
│   │   └─ Symptom selection component
│   │      - 15 pre-defined symptoms
│   │      - Custom symptom input
│   │      - Toggle symptoms on/off
│   │      - Add custom symptoms
│   │      - Remove symptoms
│   │      - Visual chips for display
│   │
│   ├── ImageUpload.tsx (102 lines)
│   │   └─ Medical image upload component
│   │      - Drag and drop support
│   │      - File browser selection
│   │      - JPG/PNG validation
│   │      - Image preview
│   │      - Remove button
│   │      - File size limits
│   │
│   ├── Loader.tsx (23 lines)
│   │   └─ Loading spinner overlay
│   │      - Full-screen overlay
│   │      - Animated spinner
│   │      - Status message
│   │      - Conditional rendering
│   │
│   └── ui/ (Shadcn UI Components)
│       ├── button.tsx
│       ├── input.tsx
│       ├── label.tsx
│       ├── card.tsx
│       ├── select.tsx
│       ├── switch.tsx
│       └── (30+ other components)
│
├── hooks/
│   └── useHealthForm.ts (143 lines)
│       └─ Custom hook for health form logic
│          - calculateRisk() function
│          - Risk scoring algorithm
│          - Condition detection
│          - Recommendation generation
│          - submitForm() function
│          - State management (result, isLoading, error)
│
├── lib/
│   ├── api.ts (198 lines)
│   │   └─ API utility functions
│   │      - predictHealthRisk() - API call function
│   │      - analyzeImage() - Image analysis
│   │      - validateHealthData() - Input validation
│   │      - fileToBase64() - File conversion
│   │      - Utility functions for formatting
│   │
│   └── utils.ts (Shadcn utility)
│       └─ cn() function for merging Tailwind classes
│
├── config/
│   └── health-config.ts (299 lines)
│       └─ Application configuration
│          - RISK_WEIGHTS (algorithm weights)
│          - COMMON_SYMPTOMS (symptom list)
│          - CONDITION_RULES (detection thresholds)
│          - RECOMMENDATIONS (template strings)
│          - FORM_CONFIG (input constraints)
│          - UI_CONFIG (animation settings)
│          - HEALTH_STANDARDS (medical guidelines)
│          - FEATURE_FLAGS (feature toggles)
│
├── public/
│   ├── icon.svg
│   ├── icon-dark-32x32.png
│   ├── icon-light-32x32.png
│   └── apple-icon.png
│
├── package.json
│   └─ Dependencies:
│      - react@^19
│      - next@16.2.0
│      - typescript@5.7.3
│      - tailwindcss@^4.2.0
│      - @radix-ui/* (UI primitives)
│      - lucide-react (icons)
│      - next-themes (theme switching)
│      - zod (validation)
│      - And 20+ more
│
├── tsconfig.json
│   └─ TypeScript configuration
│      - Strict mode enabled
│      - Path aliases (@/components, @/hooks, etc.)
│
├── tailwind.config.ts
│   └─ Tailwind CSS configuration
│      - Custom colors from CSS variables
│      - Extended theme
│
├── next.config.mjs
│   └─ Next.js configuration
│      - Optimizations
│      - Build settings
│
├── Documentation/
│   ├── README.md (337 lines)
│   │   └─ Complete user and feature documentation
│   │
│   ├── DEVELOPMENT.md (604 lines)
│   │   └─ Developer guide with architecture details
│   │
│   ├── QUICKSTART.md (398 lines)
│   │   └─ Quick start guide for getting started
│   │
│   ├── ARCHITECTURE.md (This file)
│   │   └─ Architecture and structure guide
│   │
│   ├── IMPLEMENTATION_SUMMARY.md (501 lines)
│   │   └─ Summary of what was built
│   │
│   └── .gitignore
│       └─ Git ignore patterns
│
└── .env.local (Create for API keys)
    └─ Environment variables
       - NEXT_PUBLIC_API_URL
       - ML_API_KEY (when using backend)
```

## 🔌 Component Props & State

### FormSection Props
```typescript
interface FormSectionProps {
  onSubmit: (data: FormData) => void
  isLoading: boolean
}
```

### ResultCard Props
```typescript
interface ResultCardProps {
  result: HealthRiskResult | null
  isLoading: boolean
}
```

### useHealthForm Hook Returns
```typescript
{
  result: HealthRiskResult | null
  isLoading: boolean
  error: string | null
  submitForm: (formData: FormData) => Promise<void>
  reset: () => void
}
```

## 🔀 State Flow

### Component State (FormSection)
```typescript
const [form, setForm] = useState<FormData>({
  name: '',
  age: '',
  gender: '',
  height: '',
  weight: '',
  bloodPressure: '',
  glucoseLevel: '',
  heartRate: '',
  symptoms: [],
  smoking: false,
  alcohol: false,
  exercise: false,
  image: null,
})

const [preview, setPreview] = useState<string | null>(null)
```

### Hook State (useHealthForm)
```typescript
const [result, setResult] = useState<HealthRiskResult | null>(null)
const [isLoading, setIsLoading] = useState(false)
const [error, setError] = useState<string | null>(null)
```

### Theme State (Layout)
```typescript
// Via next-themes
const { theme, setTheme } = useTheme()
// Returns: 'light' | 'dark' | 'system'
```

## 🎯 Key Function Flows

### Form Submission Flow
```
1. User fills form and clicks "Predict Risk"
   ↓
2. FormSection.handleSubmit() validates
   ↓
3. page.handleFormSubmit() called
   ↓
4. useHealthForm.submitForm() executed
   ↓
5. Loading state set to true
   ↓
6. calculateRisk() processes data (or API call)
   ↓
7. Result state updated
   ↓
8. Loading state set to false
   ↓
9. ResultCard re-renders with results
```

### Image Upload Flow
```
1. User drags/drops image or clicks to browse
   ↓
2. File selected and validated
   ↓
3. FileReader reads file as base64
   ↓
4. Preview state updated
   ↓
5. Image component re-renders
   ↓
6. Form state updated with file reference
```

### Theme Toggle Flow
```
1. User clicks theme button in Navbar
   ↓
2. setTheme() called via next-themes hook
   ↓
3. 'dark' class toggled on <html> element
   ↓
4. CSS variables switch (light/dark theme)
   ↓
5. Entire UI re-renders with new colors
   ↓
6. Preference saved to localStorage
```

## 🚀 Optimization Opportunities

### Performance
- [ ] Implement React.memo() for components
- [ ] Use useCallback() for expensive functions
- [ ] Use useMemo() for computed values
- [ ] Implement code splitting with React.lazy()
- [ ] Optimize images with next/image

### Bundle Size
- [ ] Tree-shake unused Shadcn components
- [ ] Remove unused CSS variables
- [ ] Minify API response
- [ ] Compress images

### UX
- [ ] Add form progress indicator
- [ ] Implement multi-step form
- [ ] Add keyboard shortcuts
- [ ] Cache results locally
- [ ] Add history/favorites

## 🔐 Security Considerations

### Current
- ✅ Input validation on submit
- ✅ Type safety with TypeScript
- ✅ No direct eval() or dynamic code execution
- ✅ Sanitized file uploads

### Recommended
- [ ] Add CSRF protection
- [ ] Implement rate limiting
- [ ] Add request signing
- [ ] Use HTTPS only
- [ ] Add CSP headers
- [ ] Validate on server-side
- [ ] Use secure cookies

## 📈 Scalability

### Current
- Single-page load
- Client-side calculations
- No database required

### For Growth
- [ ] Add user authentication
- [ ] Implement database
- [ ] Create API backend
- [ ] Add caching layer
- [ ] Implement CDN
- [ ] Add message queue
- [ ] Create admin panel
- [ ] Add monitoring/logging

---

**Architecture Version**: 1.0.0
**Last Updated**: April 2024
