# HealthRisk AI - Health Risk Predictor App

A modern, professional healthcare dashboard built with React.js and Next.js that provides AI-powered health risk predictions based on user input, medical data, and lifestyle factors.

## Features

### 🏥 Core Functionality
- **Health Risk Assessment**: Intelligent algorithm that analyzes multiple health factors
- **Comprehensive Input Form**: Collect basic details, body metrics, medical data, and lifestyle information
- **Symptom Tracking**: Pre-defined symptoms with custom symptom input option
- **Medical Image Upload**: Drag-and-drop support for medical images with preview
- **Real-time BMI Calculation**: Auto-calculated BMI display and categorization
- **Detailed Results Dashboard**: Risk level, percentage, detected conditions, and personalized recommendations

### 🎨 Design & UX
- **Modern Healthcare Theme**: Professional blue and green gradient design
- **Dark Mode Support**: Full light/dark theme toggle with system preference detection
- **Fully Responsive**: Optimized for mobile (single column) and desktop (split-screen layout)
- **Smooth Animations**: Fade, slide, and loading animations throughout
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation support
- **Professional Cards**: Clean cards with rounded corners, shadows, and hover effects

### 📱 Responsive Layouts
- **Desktop**: Split-screen layout (left: form, right: results)
- **Tablet/Mobile**: Stacked layout with form on top, results below
- **Touch-Friendly**: Optimized input sizes and spacing for mobile devices

## Tech Stack

### Frontend
- **React 19**: Latest React with hooks and functional components
- **Next.js 16**: Server-side rendering and static generation
- **TypeScript**: Type-safe development
- **Tailwind CSS 4**: Utility-first CSS with custom healthcare theme
- **Shadcn/ui**: Accessible component library built on Radix UI

### Components & Libraries
- **Lucide React**: Beautiful, consistent icons
- **React Hook Form**: Efficient form state management
- **next-themes**: Theme switching with system preference support
- **Recharts**: Chart visualizations (ready for expansion)

## Project Structure

```
.
├── app/
│   ├── layout.tsx           # Root layout with theme provider
│   ├── page.tsx             # Main dashboard page
│   └── globals.css          # Global styles and design tokens
├── components/
│   ├── Navbar.tsx           # Navigation with dark mode toggle
│   ├── FormSection.tsx      # Comprehensive health form
│   ├── ResultCard.tsx       # Results display component
│   ├── SymptomsSelector.tsx # Symptom selection with custom input
│   ├── ImageUpload.tsx      # Drag-and-drop medical image upload
│   ├── Loader.tsx           # Loading spinner overlay
│   └── ui/                  # Shadcn UI components
├── hooks/
│   └── useHealthForm.ts     # Custom hook for health risk calculation
├── lib/
│   └── utils.ts             # Utility functions (cn, etc.)
└── public/                  # Static assets
```

## Component Details

### FormSection Component
Comprehensive health data collection form with sections:
- **Basic Details**: Name, age, gender
- **Body Metrics**: Height, weight with live BMI calculation
- **Medical Data**: Blood pressure, glucose level, heart rate
- **Symptoms**: Checkboxes with custom symptom input
- **Lifestyle**: Smoking, alcohol, exercise toggles
- **Medical Images**: Drag-and-drop file upload

### ResultCard Component
Displays health risk assessment results:
- Risk level (Low/Medium/High) with color coding
- Risk percentage with progress bar
- Detected conditions based on medical data
- Personalized health recommendations
- BMI categorization
- Medical disclaimer

### ImageUpload Component
- Drag-and-drop support
- File type validation (JPG/PNG)
- Image preview with remove button
- File selection via button click

### SymptomsSelector Component
- Common symptoms as checkboxes
- Custom symptom input with add functionality
- Visual chips for custom symptoms
- Easy removal of selected symptoms

## Health Risk Algorithm

The risk calculation considers multiple factors:

```
Risk Percentage = Base (20%) + Age Factor + BMI Factor + Glucose Factor 
                + Blood Pressure Factor + Lifestyle Factors + Symptoms
```

### Factors Included
- **Age**: 0-25 points (higher for 60+)
- **BMI**: 0-20 points (obese = +20)
- **Glucose**: 0-25 points (diabetic range = +25)
- **Blood Pressure**: 0-20 points (hypertension = +20)
- **Smoking**: +15 points
- **Alcohol**: +8 points
- **Lack of Exercise**: +12 points
- **Symptoms**: +5 points per symptom (max 25)

### Risk Levels
- **Low**: 0-34% (Green)
- **Medium**: 35-69% (Yellow)
- **High**: 70-99% (Red)

## Color System

### Light Theme
- **Primary**: Blue (`oklch(0.55 0.15 260)`)
- **Secondary**: Green (`oklch(0.65 0.12 150)`)
- **Background**: Off-white (`oklch(0.98 0.01 260)`)
- **Foreground**: Dark (`oklch(0.15 0.02 260)`)

### Dark Theme
- **Primary**: Light Blue (`oklch(0.65 0.15 260)`)
- **Secondary**: Light Green (`oklch(0.72 0.12 150)`)
- **Background**: Near Black (`oklch(0.12 0.01 260)`)
- **Foreground**: Off-white (`oklch(0.95 0.01 260)`)

## Installation & Setup

### Prerequisites
- Node.js 18+ and npm/pnpm/yarn
- React 19+
- Next.js 16+

### Install Dependencies
```bash
npm install
# or
pnpm install
```

### Development Server
```bash
npm run dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) to view in browser.

### Build for Production
```bash
npm run build
npm start
# or
pnpm build
pnpm start
```

## Usage Guide

### Step 1: Fill in Basic Information
- Enter your name, age, and gender
- These fields are required for analysis

### Step 2: Enter Body Metrics
- Input height (in cm) and weight (in kg)
- BMI will auto-calculate and display
- BMI category is shown (underweight, normal, overweight, obese)

### Step 3: Medical Data
- Enter blood pressure (e.g., 120/80)
- Enter glucose level
- Heart rate is optional

### Step 4: Select Symptoms
- Check all applicable symptoms
- Add custom symptoms if needed
- Remove symptoms by clicking the X on custom chips

### Step 5: Lifestyle Factors
- Toggle smoking status
- Toggle alcohol consumption
- Toggle regular exercise

### Step 6: Upload Medical Image (Optional)
- Drag and drop an image or click to browse
- Supported formats: JPG, PNG
- Image preview displayed once selected
- Click to remove and choose a different image

### Step 7: Get Results
- Click "Predict Risk" button
- Wait for analysis (1-2 seconds)
- Results display in the right panel (or below on mobile)
- Scroll to view all recommendations

## API Integration

The app currently uses a client-side algorithm for risk calculation. To integrate with a real backend API:

### Example API Call (commented in code)
```typescript
// In useHealthForm.ts
const response = await fetch('/api/predict', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(formData),
})
const result = await response.json()
setResult(result)
```

### Expected API Response Format
```json
{
  "riskLevel": "Medium",
  "riskPercentage": 65,
  "detectedConditions": ["Hypertension (Elevated)", "Overweight"],
  "recommendations": [
    "Increase physical activity",
    "Monitor blood pressure regularly"
  ],
  "bmi": 26.5
}
```

## Customization

### Change Healthcare Theme Colors
Edit `/app/globals.css` and modify the color variables:
```css
:root {
  --primary: oklch(0.55 0.15 260);      /* Primary blue */
  --secondary: oklch(0.65 0.12 150);    /* Secondary green */
  /* ...other colors */
}
```

### Modify Symptoms List
Edit `components/SymptomsSelector.tsx`:
```typescript
const COMMON_SYMPTOMS = [
  'Fever',
  'Headache',
  // Add more symptoms...
]
```

### Adjust Risk Algorithm
Edit `hooks/useHealthForm.ts` in the `calculateRisk()` function to modify thresholds and factor weights.

### Change Form Fields
Edit `components/FormSection.tsx` to add/remove input fields and their validation.

## Best Practices Implemented

✅ **Performance**
- React functional components with hooks
- Memoized callbacks where needed
- Optimized re-renders
- Lazy loading support ready

✅ **Accessibility**
- ARIA labels and roles
- Semantic HTML elements
- Keyboard navigation support
- Screen reader friendly
- Contrast ratios meet WCAG AA

✅ **Code Quality**
- TypeScript for type safety
- Clean component structure
- Reusable custom hooks
- Proper error handling
- Well-commented code

✅ **User Experience**
- Real-time form validation
- Loading states with spinners
- Smooth animations
- Responsive design
- Dark mode support
- Mobile-first approach

## Error Handling

The app includes error handling for:
- Missing required fields
- Invalid file uploads
- API call failures
- Form validation errors

Users receive helpful error messages and can retry operations.

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 15+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Future Enhancements

- [ ] Backend API integration for real ML predictions
- [ ] User authentication and history
- [ ] PDF report generation
- [ ] Multi-language support
- [ ] Advanced analytics and trends
- [ ] Integration with wearable devices
- [ ] Video consultation scheduling
- [ ] Medication interactions checker

## Disclaimer

**Important**: This application is for informational and educational purposes only. It is not intended to replace professional medical advice, diagnosis, or treatment. Always consult with a qualified healthcare provider before making any health-related decisions.

## License

MIT License - Feel free to use this project for commercial or personal purposes.

## Support

For issues, questions, or contributions, please visit our GitHub repository or contact support.

---

**Built with ❤️ for better health insights**
