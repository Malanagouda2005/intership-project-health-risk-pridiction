# Development Guide - HealthRisk AI

A comprehensive guide for developers to understand, customize, and extend the Health Risk Predictor application.

## Table of Contents

1. [Project Structure](#project-structure)
2. [Architecture Overview](#architecture-overview)
3. [Component Deep Dive](#component-deep-dive)
4. [State Management](#state-management)
5. [Styling System](#styling-system)
6. [API Integration](#api-integration)
7. [Testing](#testing)
8. [Performance Optimization](#performance-optimization)
9. [Deployment](#deployment)
10. [Troubleshooting](#troubleshooting)

## Project Structure

```
health-risk-predictor/
├── app/
│   ├── api/
│   │   └── predict/
│   │       └── route.ts          # API endpoint for predictions
│   ├── layout.tsx                # Root layout with theme
│   ├── page.tsx                  # Main dashboard
│   ├── globals.css               # Global styles & theme tokens
│   └── favicon.ico               # App icon
├── components/
│   ├── ui/                       # Shadcn UI components
│   ├── Navbar.tsx                # App navbar
│   ├── FormSection.tsx           # Main form component
│   ├── ResultCard.tsx            # Results display
│   ├── SymptomsSelector.tsx      # Symptom checkboxes
│   ├── ImageUpload.tsx           # Image upload with drag-drop
│   └── Loader.tsx                # Loading spinner
├── hooks/
│   └── useHealthForm.ts          # Custom hook for form logic
├── lib/
│   ├── api.ts                    # API utility functions
│   └── utils.ts                  # General utilities
├── config/
│   └── health-config.ts          # App configuration
├── public/                       # Static assets
├── styles/                       # Additional stylesheets
├── package.json                  # Dependencies
├── tsconfig.json                 # TypeScript config
├── tailwind.config.ts            # Tailwind configuration
├── next.config.mjs               # Next.js configuration
├── README.md                     # User documentation
└── DEVELOPMENT.md                # This file
```

## Architecture Overview

### Data Flow

```
User Input (Form)
    ↓
FormSection Component (React state)
    ↓
handleFormSubmit()
    ↓
useHealthForm Hook
    ↓
Risk Calculation / API Call
    ↓
ResultCard Component (Display)
```

### Component Hierarchy

```
Page (Main Dashboard)
├── Navbar
├── FormSection
│   ├── Basic Details Inputs
│   ├── Body Metrics Inputs
│   ├── Medical Data Inputs
│   ├── SymptomsSelector
│   │   ├── Checkboxes (Common)
│   │   └── Custom Symptom Input
│   ├── Lifestyle Toggles
│   ├── ImageUpload
│   │   ├── Drag-Drop Area
│   │   └── File Input
│   └── Submit Button
├── ResultCard
│   ├── Risk Level Display
│   ├── Risk Percentage Bar
│   ├── BMI Display
│   ├── Detected Conditions
│   ├── Recommendations
│   └── Medical Disclaimer
└── Loader (Overlay)
```

## Component Deep Dive

### FormSection Component

**Location**: `components/FormSection.tsx`

**Responsibility**: Manages all health data input fields

**Key Features**:
- Form state management with React hooks
- Real-time BMI calculation
- Section-based organization
- Input validation on submit
- Support for optional fields

**State Management**:
```typescript
const [form, setForm] = useState<FormData>({
  name: '',
  age: '',
  gender: '',
  // ... other fields
})
```

**Key Functions**:
- `handleInputChange()`: Updates text/number inputs
- `handleSelectChange()`: Updates dropdown selections
- `handleToggle()`: Updates boolean toggles
- `handleImageChange()`: Manages image file
- `handleSubmit()`: Validates and submits form

**Customization Points**:
1. Add new input fields
2. Modify validation rules
3. Change section order
4. Add/remove lifecycle handling

### ResultCard Component

**Location**: `components/ResultCard.tsx`

**Responsibility**: Displays health risk assessment results

**Key Features**:
- Risk level with color coding
- Progress bar visualization
- BMI categorization
- Detected conditions list
- Personalized recommendations
- Medical disclaimer

**Props**:
```typescript
interface ResultCardProps {
  result: HealthRiskResult | null
  isLoading: boolean
}
```

**Conditional Rendering**:
- Loading state: Skeleton placeholders
- No result state: Empty state message
- With result: Full assessment display

### useHealthForm Hook

**Location**: `hooks/useHealthForm.ts`

**Responsibility**: Health risk calculation and form submission

**Key Functions**:
```typescript
calculateRisk(formData: FormData): HealthRiskResult
submitForm(formData: FormData): Promise<void>
reset(): void
```

**Risk Calculation Algorithm**:
1. Base risk: 20%
2. Apply age factor (+0-25%)
3. Apply BMI factor (+0-20%)
4. Apply glucose factor (+0-25%)
5. Apply blood pressure factor (+0-20%)
6. Apply lifestyle factors (+0-35%)
7. Apply symptoms factor (+0-25%)
8. Cap at 99%

**To Replace with API Call**:
```typescript
// In submitForm function, replace:
const calculatedResult = calculateRisk(formData)

// With:
const calculatedResult = await predictHealthRisk(formData)
```

## State Management

### Local State (Component Level)

All form state is managed locally in FormSection:
```typescript
const [form, setForm] = useState<FormData>({...})
const [preview, setPreview] = useState<string | null>(null)
```

### Custom Hook State

Results and loading state managed in useHealthForm:
```typescript
const [result, setResult] = useState<HealthRiskResult | null>(null)
const [isLoading, setIsLoading] = useState(false)
const [error, setError] = useState<string | null>(null)
```

### Theme State

Theme managed by next-themes in layout:
```typescript
<ThemeProvider attribute="class" defaultTheme="system" enableSystem>
```

### Future: Global State

If needed, consider adding:
- Redux Toolkit
- Zustand
- Jotai
- Context API with useReducer

## Styling System

### Design Tokens

Located in `app/globals.css`:

```css
:root {
  --primary: oklch(0.55 0.15 260);      /* Blue */
  --secondary: oklch(0.65 0.12 150);    /* Green */
  --background: oklch(0.98 0.01 260);
  --foreground: oklch(0.15 0.02 260);
  /* ... more tokens */
}
```

### Tailwind Configuration

Located in `tailwind.config.ts`:

```typescript
theme: {
  colors: {
    primary: 'var(--primary)',
    secondary: 'var(--secondary)',
    // ...
  }
}
```

### Customizing Colors

1. **Light Theme**: Modify `:root` variables in globals.css
2. **Dark Theme**: Modify `.dark` variables in globals.css
3. **Component Overrides**: Use inline Tailwind classes

### Theme Switching

Implemented via next-themes:
```typescript
const { theme, setTheme } = useTheme()

// Toggle theme
setTheme(theme === 'dark' ? 'light' : 'dark')
```

## API Integration

### Current Implementation

The app uses client-side calculations in `hooks/useHealthForm.ts`.

### To Switch to Backend API

1. **Enable API Route** (already created in `app/api/predict/route.ts`)

2. **Update useHealthForm.ts**:
```typescript
// Replace:
const calculatedResult = calculateRisk(formData)

// With:
const calculatedResult = await predictHealthRisk(formData)
```

3. **Import API function**:
```typescript
import { predictHealthRisk } from '@/lib/api'
```

4. **Handle API errors**:
```typescript
try {
  const result = await predictHealthRisk(formData)
  setResult(result)
} catch (error) {
  setError(error.message)
}
```

### Example: Integrating with External ML API

```typescript
// In app/api/predict/route.ts
const mlResponse = await fetch('https://ml-api.example.com/predict', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${process.env.ML_API_KEY}` },
  body: JSON.stringify(body),
})

const mlResult = await mlResponse.json()
return NextResponse.json(mlResult)
```

### API Response Format

```typescript
interface HealthRiskResult {
  riskLevel: 'Low' | 'Medium' | 'High'
  riskPercentage: number  // 0-99
  detectedConditions: string[]
  recommendations: string[]
  bmi: number
}
```

## Testing

### Unit Tests Example

```typescript
// __tests__/hooks/useHealthForm.test.ts
import { renderHook, act } from '@testing-library/react'
import { useHealthForm } from '@/hooks/useHealthForm'

describe('useHealthForm', () => {
  it('calculates risk correctly', () => {
    const { result } = renderHook(() => useHealthForm())
    
    act(() => {
      result.current.submitForm({...testData})
    })

    expect(result.current.result?.riskLevel).toBe('Medium')
  })
})
```

### Integration Tests Example

```typescript
// __tests__/FormSection.test.tsx
import { render, screen, fireEvent } from '@testing-library/react'
import { FormSection } from '@/components/FormSection'

describe('FormSection', () => {
  it('submits form with valid data', async () => {
    const onSubmit = jest.fn()
    render(<FormSection onSubmit={onSubmit} isLoading={false} />)
    
    // Fill form fields...
    // Click submit...
    
    expect(onSubmit).toHaveBeenCalled()
  })
})
```

### E2E Tests Example

```typescript
// e2e/health-assessment.spec.ts
import { test, expect } from '@playwright/test'

test('complete health assessment flow', async ({ page }) => {
  await page.goto('/')
  
  // Fill form
  await page.fill('input[name="name"]', 'John Doe')
  // ... fill other fields
  
  // Submit
  await page.click('button:has-text("Predict Risk")')
  
  // Verify results
  await expect(page).toContainText('Risk Assessment')
})
```

## Performance Optimization

### Current Optimizations

1. **Code Splitting**: Next.js automatic splitting
2. **Image Optimization**: Next.js Image component ready
3. **CSS Optimization**: Tailwind CSS purging
4. **Component Memoization**: React.memo ready
5. **Hook Optimization**: useCallback/useMemo ready

### Recommended Enhancements

```typescript
// Memoize heavy components
export const FormSection = React.memo(FormSectionComponent)

// Memoize callbacks
const handleSubmit = useCallback((formData: FormData) => {
  submitForm(formData)
}, [submitForm])

// Memoize computed values
const bmi = useMemo(() => {
  return weight / (height / 100) ** 2
}, [weight, height])
```

### Bundle Size Analysis

```bash
npm run build
# Analyze with next/bundle-analyzer
```

### Performance Metrics

- First Contentful Paint (FCP): < 1s
- Largest Contentful Paint (LCP): < 2.5s
- Cumulative Layout Shift (CLS): < 0.1
- Core Web Vitals: All green

## Deployment

### Prerequisites

- Node.js 18+
- Git
- Vercel account (recommended)
- Environment variables set up

### Deployment Steps

#### Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Or push to GitHub and connect to Vercel dashboard
```

#### Self-Hosted (Docker)

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

EXPOSE 3000
CMD ["npm", "start"]
```

#### Environment Variables

```bash
# .env.local
NEXT_PUBLIC_API_URL=https://api.example.com
ML_API_KEY=your_api_key_here
```

### Production Checklist

- [ ] Environment variables configured
- [ ] API endpoints verified
- [ ] SSL certificate configured
- [ ] CORS headers set up
- [ ] Rate limiting enabled
- [ ] Error tracking (Sentry) configured
- [ ] Analytics enabled
- [ ] Security headers added
- [ ] Database backups configured
- [ ] Monitoring/alerts set up

## Troubleshooting

### Common Issues

#### 1. Theme Not Applying

**Problem**: Dark mode toggle doesn't work

**Solution**:
```typescript
// Ensure ThemeProvider in layout.tsx
<ThemeProvider attribute="class" defaultTheme="system">
  {children}
</ThemeProvider>

// Use 'dark' class on html element
<html lang="en" suppressHydrationWarning>
```

#### 2. Image Upload Not Working

**Problem**: Image preview not displaying

**Solution**:
```typescript
// Ensure FileReader is set up correctly
const reader = new FileReader()
reader.onloadend = () => {
  setPreview(reader.result as string)
}
reader.readAsDataURL(file)
```

#### 3. Form Validation Not Working

**Problem**: Required fields not being validated

**Solution**:
```typescript
// Check handleSubmit validation
const handleSubmit = (e) => {
  e.preventDefault()
  if (!form.name || !form.age || !form.gender || !form.height || !form.weight) {
    alert('Please fill in all required fields')
    return
  }
  onSubmit(form)
}
```

#### 4. Performance Issues

**Problem**: App loads slowly

**Solution**:
1. Check bundle size: `npm run build`
2. Optimize images
3. Enable code splitting
4. Reduce re-renders with useMemo
5. Use React.lazy() for large components

#### 5. Styling Not Working

**Problem**: Tailwind classes not applying

**Solution**:
```typescript
// Verify tailwind.config.ts has correct paths
content: [
  './app/**/*.{js,ts,jsx,tsx}',
  './components/**/*.{js,ts,jsx,tsx}',
]

// Clear cache
rm -rf .next
npm run dev
```

### Debug Mode

Enable debug logging:

```typescript
// In hooks/useHealthForm.ts
if (process.env.NODE_ENV === 'development') {
  console.log('[DEBUG] Form Data:', formData)
  console.log('[DEBUG] Risk Calculation:', calculatedResult)
}
```

### Get Help

1. **Documentation**: Read README.md
2. **Code Comments**: Check inline documentation
3. **GitHub Issues**: Search existing issues
4. **Community**: Ask on Reddit/Stack Overflow
5. **Support**: Contact support@healthrisk.ai

---

**Last Updated**: April 2024
**Version**: 1.0.0
