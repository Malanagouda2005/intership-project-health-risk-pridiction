'use client'

import { useState } from 'react'
import { Navbar } from '@/components/Navbar'
import { FormSection } from '@/components/FormSection'
import { ResultCard } from '@/components/ResultCard'
import { Loader } from '@/components/Loader'
import { useHealthForm } from '@/hooks/useHealthForm'
import type { FormData } from '@/components/FormSection'

export default function Home() {
  const { result, isLoading, submitForm } = useHealthForm()
  const [scrollToResults, setScrollToResults] = useState(false)

  const handleFormSubmit = async (formData: FormData) => {
    setScrollToResults(true)
    await submitForm(formData)
    // Scroll to results on desktop
    setTimeout(() => {
      if (window.innerWidth >= 1024) {
        const resultsElement = document.getElementById('results-section')
        resultsElement?.scrollIntoView({ behavior: 'smooth' })
      }
    }, 100)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <Navbar />
      <Loader isLoading={isLoading} message="Analyzing your health data..." />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Split-Screen Layout */}
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Left Panel - Form */}
          <div className="flex flex-col">
            <FormSection onSubmit={handleFormSubmit} isLoading={isLoading} />
          </div>

          {/* Right Panel - Results */}
          <div className="flex flex-col" id="results-section">
            <ResultCard result={result} isLoading={isLoading} />
          </div>
        </div>

        {/* Mobile Results (shown below form on mobile) */}
        <div className="mt-8 lg:hidden">
          {(result || scrollToResults) && (
            <div>
              <ResultCard result={result} isLoading={isLoading} />
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border bg-white dark:bg-slate-950">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2024 HealthRisk AI - Your AI-Powered Health Assessment Tool</p>
            <p className="mt-2">
              Disclaimer: This tool provides informational assessments only. Please consult a
              healthcare professional for medical advice.
            </p>
          </div>
        </div>
      </footer>
    </main>
  )
}
