/**
 * Health Risk Prediction API Route
 * 
 * This is an example API route for backend integration.
 * Currently, the app uses client-side calculations in useHealthForm hook.
 * 
 * To enable this API:
 * 1. Uncomment the fetch call in hooks/useHealthForm.ts
 * 2. Implement your backend logic here
 * 3. Return a HealthRiskResult object
 * 
 * Expected request body:
 * {
 *   name: string
 *   age: number
 *   gender: string
 *   height: number
 *   weight: number
 *   bloodPressure?: string
 *   glucoseLevel?: number
 *   heartRate?: number
 *   symptoms: string[]
 *   smoking: boolean
 *   alcohol: boolean
 *   exercise: boolean
 * }
 * 
 * Expected response:
 * {
 *   riskLevel: 'Low' | 'Medium' | 'High'
 *   riskPercentage: number (0-99)
 *   detectedConditions: string[]
 *   recommendations: string[]
 *   bmi: number
 * }
 */

import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.name || !body.age || !body.gender || !body.height || !body.weight) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Validate data types and ranges
    if (
      typeof body.age !== 'number' ||
      body.age < 0 ||
      body.age > 150 ||
      typeof body.height !== 'number' ||
      body.height < 50 ||
      body.height > 250 ||
      typeof body.weight !== 'number' ||
      body.weight < 20 ||
      body.weight > 500
    ) {
      return NextResponse.json(
        { error: 'Invalid data ranges' },
        { status: 400 }
      )
    }

    // Calculate BMI
    const bmi = body.weight / (body.height / 100) ** 2

    // TODO: Implement your ML/AI logic here
    // This could call to a Python backend, ML API, or other service
    // Example:
    // const result = await callMLBackend(body)
    // or
    // const result = await fetch('https://ml-api.example.com/predict', {...})

    // Placeholder logic - Replace with real prediction
    let riskPercentage = 20
    const conditions: string[] = []
    const recommendations: string[] = []

    // Age factor
    if (body.age > 60) riskPercentage += 25
    else if (body.age > 45) riskPercentage += 15

    // BMI factor
    if (bmi > 30) {
      riskPercentage += 20
      conditions.push('Obesity')
    } else if (bmi > 25) {
      riskPercentage += 10
      conditions.push('Overweight')
    }

    // Glucose factor
    if (body.glucoseLevel > 126) {
      riskPercentage += 25
      conditions.push('Potential Diabetes')
    } else if (body.glucoseLevel > 100) {
      riskPercentage += 15
    }

    // Blood pressure factor
    if (body.bloodPressure) {
      const [systolic] = body.bloodPressure.split('/').map(Number)
      if (systolic > 140) {
        riskPercentage += 20
        conditions.push('Hypertension (High)')
      } else if (systolic > 130) {
        riskPercentage += 10
        conditions.push('Hypertension (Elevated)')
      }
    }

    // Lifestyle factors
    if (body.smoking) riskPercentage += 15
    if (body.alcohol) riskPercentage += 8
    if (!body.exercise) riskPercentage += 12

    // Symptoms factor
    if (body.symptoms && Array.isArray(body.symptoms)) {
      riskPercentage += Math.min(body.symptoms.length * 5, 25)

      // Check for cardiovascular symptoms
      if (body.symptoms.some((s: string) =>
        ['Chest Pain', 'Shortness of Breath'].includes(s)
      )) {
        conditions.push('Possible Cardiovascular Risk')
      }
    }

    // Cap at 99%
    riskPercentage = Math.min(Math.round(riskPercentage), 99)

    // Determine risk level
    let riskLevel: 'Low' | 'Medium' | 'High'
    if (riskPercentage < 35) riskLevel = 'Low'
    else if (riskPercentage < 70) riskLevel = 'Medium'
    else riskLevel = 'High'

    // Generate recommendations
    if (bmi > 25) recommendations.push('Consider a balanced diet and weight management program')
    if (!body.exercise) recommendations.push('Increase physical activity to at least 150 minutes per week')
    if (body.smoking) recommendations.push('Consult with a healthcare provider about smoking cessation')
    if (body.glucoseLevel > 100)
      recommendations.push('Monitor glucose levels and discuss diabetes prevention with your doctor')
    if (body.symptoms && body.symptoms.length > 0)
      recommendations.push('Schedule a consultation with a healthcare professional')

    // Return prediction
    return NextResponse.json(
      {
        riskLevel,
        riskPercentage,
        detectedConditions: conditions.length > 0 ? conditions : ['No specific conditions detected'],
        recommendations: recommendations.slice(0, 5),
        bmi: parseFloat(bmi.toFixed(1)),
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Prediction error:', error)
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    )
  }
}

/**
 * Example of calling an external ML API:
 * 
 * async function callExternalMLAPI(data: any) {
 *   const response = await fetch('https://api.example.com/predict', {
 *     method: 'POST',
 *     headers: {
 *       'Content-Type': 'application/json',
 *       'Authorization': `Bearer ${process.env.ML_API_KEY}`,
 *     },
 *     body: JSON.stringify(data),
 *   })
 * 
 *   if (!response.ok) throw new Error('ML API error')
 *   return response.json()
 * }
 */

/**
 * Example of calling a Python backend:
 * 
 * async function callPythonBackend(data: any) {
 *   const response = await fetch('http://localhost:8000/predict', {
 *     method: 'POST',
 *     headers: {
 *       'Content-Type': 'application/json',
 *     },
 *     body: JSON.stringify(data),
 *   })
 * 
 *   if (!response.ok) throw new Error('Python backend error')
 *   return response.json()
 * }
 */
