import { useState } from 'react'

export interface HealthRiskResult {
  riskLevel: 'Low' | 'Medium' | 'High'
  riskPercentage: number
  detectedConditions: string[]
  recommendations: string[]
  bmi: number
}

export interface FormData {
  name: string
  age: string
  gender: string
  height: string
  weight: string
  bloodPressure: string
  glucoseLevel: string
  heartRate: string
  symptoms: string[]
  smoking: boolean
  alcohol: boolean
  exercise: boolean
  image: File | null
}

export function useHealthForm() {
  const [result, setResult] = useState<HealthRiskResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const calculateRisk = (formData: FormData): HealthRiskResult => {
    const age = parseInt(formData.age)
    const bmi = parseFloat(formData.weight) / (parseFloat(formData.height) / 100) ** 2
    const glucose = parseFloat(formData.glucoseLevel)
    const symptoms = formData.symptoms.length

    let riskPercentage = 20 // Base risk

    // Age factor
    if (age > 60) riskPercentage += 25
    else if (age > 45) riskPercentage += 15
    else if (age > 35) riskPercentage += 8

    // BMI factor
    if (bmi > 30) riskPercentage += 20
    else if (bmi > 25) riskPercentage += 10

    // Glucose factor
    if (glucose > 126) riskPercentage += 25
    else if (glucose > 100) riskPercentage += 15

    // Blood pressure factor
    if (formData.bloodPressure) {
      const [systolic] = formData.bloodPressure.split('/').map(Number)
      if (systolic > 140) riskPercentage += 20
      else if (systolic > 130) riskPercentage += 10
    }

    // Lifestyle factors
    if (formData.smoking) riskPercentage += 15
    if (formData.alcohol) riskPercentage += 8
    if (!formData.exercise) riskPercentage += 12

    // Symptoms factor
    riskPercentage += Math.min(symptoms * 5, 25)

    // Cap at 99%
    riskPercentage = Math.min(riskPercentage, 99)

    // Determine risk level
    let riskLevel: 'Low' | 'Medium' | 'High'
    if (riskPercentage < 35) riskLevel = 'Low'
    else if (riskPercentage < 70) riskLevel = 'Medium'
    else riskLevel = 'High'

    // Detect conditions
    const conditions: string[] = []
    if (glucose > 126) conditions.push('Potential Diabetes')
    if (bmi > 30) conditions.push('Obesity')
    if (formData.bloodPressure) {
      const [systolic] = formData.bloodPressure.split('/').map(Number)
      if (systolic > 140) conditions.push('Hypertension (High)')
      else if (systolic > 130) conditions.push('Hypertension (Elevated)')
    }
    if (formData.symptoms.some((s) =>
      ['Chest Pain', 'Shortness of Breath'].includes(s)
    ))
      conditions.push('Possible Cardiovascular Risk')

    // Generate recommendations
    const recommendations: string[] = []
    if (bmi > 25) recommendations.push('Consider a balanced diet and weight management program')
    if (!formData.exercise)
      recommendations.push('Increase physical activity to at least 150 minutes per week')
    if (formData.smoking) recommendations.push('Consult with a healthcare provider about smoking cessation')
    if (glucose > 100)
      recommendations.push('Monitor glucose levels and discuss diabetes prevention with your doctor')
    if (formData.symptoms.length > 0)
      recommendations.push('Schedule a consultation with a healthcare professional')
    recommendations.push('Maintain regular health check-ups and screenings')

    return {
      riskLevel,
      riskPercentage: Math.round(riskPercentage),
      detectedConditions: conditions.length > 0 ? conditions : ['No specific conditions detected'],
      recommendations: recommendations.slice(0, 5),
      bmi: parseFloat(bmi.toFixed(1)),
    }
  }

  const submitForm = async (formData: FormData) => {
    setIsLoading(true)
    setError(null)

    try {
      // Simulate API call with delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Calculate risk based on form data
      const calculatedResult = calculateRisk(formData)
      setResult(calculatedResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  const reset = () => {
    setResult(null)
    setError(null)
  }

  return {
    result,
    isLoading,
    error,
    submitForm,
    reset,
  }
}
