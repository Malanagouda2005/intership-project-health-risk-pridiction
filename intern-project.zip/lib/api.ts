/**
 * API Utility Functions
 * 
 * This file contains reusable API functions for communicating with the backend.
 * Currently set up for future integration - the app uses client-side algorithms.
 */

export interface ApiErrorResponse {
  error: string
  statusCode: number
  message?: string
}

export interface HealthPredictionRequest {
  name: string
  age: number
  gender: string
  height: number
  weight: number
  bloodPressure?: string
  glucoseLevel?: number
  heartRate?: number
  symptoms: string[]
  smoking: boolean
  alcohol: boolean
  exercise: boolean
  imageBase64?: string
}

export interface HealthPredictionResponse {
  riskLevel: 'Low' | 'Medium' | 'High'
  riskPercentage: number
  detectedConditions: string[]
  recommendations: string[]
  bmi: number
}

/**
 * Predicts health risk based on user data
 * @param data - User health data
 * @returns Health risk prediction
 */
export async function predictHealthRisk(
  data: HealthPredictionRequest
): Promise<HealthPredictionResponse> {
  try {
    const response = await fetch('/api/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      const error: ApiErrorResponse = await response.json()
      throw new Error(error.message || error.error || 'Failed to predict health risk')
    }

    const result: HealthPredictionResponse = await response.json()
    return result
  } catch (error) {
    console.error('Health prediction error:', error)
    throw error
  }
}

/**
 * Analyzes medical image using AI
 * @param imageBase64 - Base64 encoded image
 * @returns Image analysis result
 */
export async function analyzeImage(imageBase64: string): Promise<{
  findings: string[]
  severity: 'low' | 'medium' | 'high'
  confidence: number
}> {
  try {
    const response = await fetch('/api/analyze-image', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ image: imageBase64 }),
    })

    if (!response.ok) {
      throw new Error('Failed to analyze image')
    }

    return await response.json()
  } catch (error) {
    console.error('Image analysis error:', error)
    throw error
  }
}

/**
 * Validates user input data
 * @param data - User data to validate
 * @returns Validation result with errors if any
 */
export function validateHealthData(data: Partial<HealthPredictionRequest>): {
  isValid: boolean
  errors: Record<string, string>
} {
  const errors: Record<string, string> = {}

  // Validate required fields
  if (!data.name?.trim()) errors.name = 'Name is required'
  if (!data.age || data.age < 0 || data.age > 150) errors.age = 'Valid age is required'
  if (!data.gender) errors.gender = 'Gender is required'
  if (!data.height || data.height < 50 || data.height > 250)
    errors.height = 'Valid height is required'
  if (!data.weight || data.weight < 20 || data.weight > 500)
    errors.weight = 'Valid weight is required'

  // Validate optional medical fields
  if (data.bloodPressure) {
    const [systolic, diastolic] = data.bloodPressure.split('/').map(Number)
    if (!systolic || !diastolic || systolic < 50 || systolic > 300)
      errors.bloodPressure = 'Valid blood pressure is required (e.g., 120/80)'
  }

  if (data.glucoseLevel && (data.glucoseLevel < 40 || data.glucoseLevel > 500))
    errors.glucoseLevel = 'Valid glucose level is required'

  if (data.heartRate && (data.heartRate < 30 || data.heartRate > 200))
    errors.heartRate = 'Valid heart rate is required'

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}

/**
 * Converts file to base64 string
 * @param file - File to convert
 * @returns Base64 encoded string
 */
export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      const result = reader.result as string
      resolve(result.split(',')[1] || result)
    }
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

/**
 * Formats health recommendations for display
 * @param recommendations - Raw recommendations
 * @returns Formatted recommendations
 */
export function formatRecommendations(recommendations: string[]): string[] {
  return recommendations.map((rec) => {
    // Capitalize first letter
    return rec.charAt(0).toUpperCase() + rec.slice(1)
  })
}

/**
 * Calculates BMI category
 * @param bmi - BMI value
 * @returns BMI category
 */
export function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return 'Underweight'
  if (bmi < 25) return 'Normal weight'
  if (bmi < 30) return 'Overweight'
  return 'Obese'
}

/**
 * Formats blood pressure display
 * @param pressure - Blood pressure string
 * @returns Formatted pressure with status
 */
export function formatBloodPressure(pressure: string): {
  display: string
  status: string
} {
  const [systolic, diastolic] = pressure.split('/').map(Number)

  let status = 'Normal'
  if (systolic >= 140 || diastolic >= 90) status = 'High'
  else if (systolic >= 130 || diastolic >= 80) status = 'Elevated'

  return {
    display: pressure,
    status,
  }
}
