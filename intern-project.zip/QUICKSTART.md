# Quick Start Guide - HealthRisk AI

Get the Health Risk Predictor app up and running in minutes!

## ⚡ Installation (2 minutes)

### Option 1: Using npm

```bash
# Clone or extract the project
cd health-risk-predictor

# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Option 2: Using pnpm

```bash
pnpm install
pnpm dev
```

### Option 3: Using yarn

```bash
yarn install
yarn dev
```

## 🎯 First Run

1. **Open the App**: Navigate to `http://localhost:3000`
2. **See the Dashboard**: Modern split-screen layout with form on left, results on right
3. **Toggle Theme**: Click sun/moon icon in navbar to test dark mode
4. **Fill the Form**: Enter sample health data
5. **Get Predictions**: Click "Predict Risk" to see results

## 📋 Sample Data to Try

### Scenario 1: Low Risk
```
Name: John Smith
Age: 30
Gender: Male
Height: 175 cm
Weight: 70 kg
Blood Pressure: 120/80
Glucose Level: 95
Symptoms: None
Lifestyle: Exercise yes, No smoking, No alcohol
```
**Expected Result**: Low Risk (15-30%)

### Scenario 2: Medium Risk
```
Name: Jane Doe
Age: 45
Gender: Female
Height: 165 cm
Weight: 75 kg
Blood Pressure: 135/85
Glucose Level: 115
Symptoms: Fatigue, Headache
Lifestyle: Exercise no, Smoking yes, Alcohol yes
```
**Expected Result**: Medium Risk (45-65%)

### Scenario 3: High Risk
```
Name: Robert Johnson
Age: 65
Gender: Male
Height: 170 cm
Weight: 95 kg
Blood Pressure: 150/95
Glucose Level: 145
Symptoms: Chest Pain, Shortness of Breath, Fatigue
Lifestyle: Exercise no, Smoking yes, Alcohol yes
```
**Expected Result**: High Risk (75-90%)

## 📱 Responsive Design

### Desktop (≥1024px)
- **Layout**: Side-by-side (form left, results right)
- **Best Experience**: Full screen view
- **Resolution**: 1920x1080 or higher recommended

### Tablet (768px - 1024px)
- **Layout**: Stacked (form top, results below)
- **Scroll**: Vertical scrolling
- **Touch**: Optimized for touch input

### Mobile (< 768px)
- **Layout**: Single column
- **Form**: Scrollable
- **Results**: Appear below form
- **Input**: Large touch targets

**Resize your browser** to test responsive behavior!

## 🎨 Customization

### Change App Title
Edit `app/layout.tsx`:
```typescript
export const metadata: Metadata = {
  title: 'Your Custom Title',
  description: 'Your custom description',
}
```

### Change Colors
Edit `app/globals.css`:
```css
:root {
  --primary: oklch(0.55 0.15 260);      /* Change this to primary color */
  --secondary: oklch(0.65 0.12 150);    /* Change this to secondary color */
}
```

### Add New Symptoms
Edit `components/SymptomsSelector.tsx`:
```typescript
const COMMON_SYMPTOMS = [
  'Fever',
  'Headache',
  'Your New Symptom',  // Add here
  // ...
]
```

### Change Risk Thresholds
Edit `hooks/useHealthForm.ts` in the `calculateRisk()` function:
```typescript
// Modify these values
if (age > 60) riskPercentage += 25  // Change 25 to another value
```

## 🚀 Development

### Available Scripts

```bash
# Development server
npm run dev

# Build for production
npm run build

# Run production build locally
npm start

# Run linting
npm run lint
```

### File Structure Explained

```
components/
├── Navbar.tsx          # Top navigation bar
├── FormSection.tsx     # Health data input form
├── ResultCard.tsx      # Risk assessment results
├── SymptomsSelector.tsx # Symptom checkboxes
├── ImageUpload.tsx     # Image upload area
└── Loader.tsx          # Loading spinner

hooks/
└── useHealthForm.ts    # Health calculation logic

app/
├── page.tsx            # Main dashboard
├── layout.tsx          # App layout & theme
└── globals.css         # Colors & styles
```

## 🔧 Configuration

### Config File Location
`config/health-config.ts`

### Key Settings
```typescript
export const RISK_WEIGHTS = {
  BASE_RISK: 20,
  AGE_SENIOR: { threshold: 100, points: 25 },
  // ...
}

export const COMMON_SYMPTOMS = [
  'Fever',
  'Headache',
  // ...
]
```

## 📊 Understanding Results

### Risk Levels

**🟢 Low (0-34%)**
- Generally good health indicators
- Recommendations: Maintain healthy lifestyle
- Action: Annual check-ups

**🟡 Medium (35-69%)**
- Some health risk factors present
- Recommendations: Lifestyle modifications
- Action: Schedule doctor appointment

**🔴 High (70-99%)**
- Multiple risk factors detected
- Recommendations: Urgent medical consultation
- Action: See healthcare provider immediately

### What's Calculated

1. **BMI** - Body Mass Index
2. **Risk Percentage** - Overall health risk score
3. **Conditions** - Detected health issues
4. **Recommendations** - Personalized advice

## 🐛 Troubleshooting

### Port 3000 Already in Use

```bash
# macOS/Linux
lsof -i :3000
kill -9 <PID>

# Windows (PowerShell)
Get-Process -Id (Get-NetTCPConnection -LocalPort 3000).OwningProcess | Stop-Process
```

### Dependencies Not Installing

```bash
# Clear cache
npm cache clean --force

# Delete node_modules and lock file
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

### Styling Not Working

```bash
# Clear Next.js cache
rm -rf .next

# Restart dev server
npm run dev
```

### Theme Not Switching

- Hard refresh: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
- Clear browser cache
- Check browser console for errors

### Image Upload Not Working

- Ensure file is JPG or PNG
- Check file size (max 5MB)
- Try different image
- Check browser console for errors

## 📚 Learning Resources

### Component Understanding

- **FormSection**: Shows how to manage form state
- **SymptomsSelector**: Shows conditional rendering & lists
- **ImageUpload**: Shows file handling & drag-drop
- **ResultCard**: Shows conditional displays

### Hook Understanding

- **useHealthForm**: Shows custom hook pattern
- **useTheme**: Shows next-themes integration
- See `hooks/` for more examples

### Styling Understanding

- **app/globals.css**: Design tokens system
- **Tailwind CSS**: Utility-first approach
- **Dark mode**: CSS custom properties

## 🎓 Next Steps

### 1. Explore Components
- Open each component file
- Read the comments
- Understand the structure

### 2. Modify Values
- Change risk weights in config
- Add/remove symptoms
- Adjust color scheme

### 3. Add Features
- Add more form fields
- Implement export to PDF
- Add user authentication
- Create results history

### 4. Connect Backend
- Uncomment API call in `useHealthForm`
- Implement `/api/predict` endpoint
- Add authentication if needed
- Test with real ML models

## 📞 Support & Help

### Documentation Files

- **README.md** - Full documentation
- **DEVELOPMENT.md** - Developer guide
- **QUICKSTART.md** - This file
- **config/health-config.ts** - Configuration options

### Getting Help

1. Check README.md for detailed info
2. Read DEVELOPMENT.md for architecture
3. Check code comments
4. Look at config files for customization

## 🎉 Success Checklist

- [ ] App loads at http://localhost:3000
- [ ] Form accepts input
- [ ] "Predict Risk" button works
- [ ] Results display correctly
- [ ] Dark mode toggle works
- [ ] Image upload works
- [ ] Responsive design works (test on mobile)
- [ ] No console errors

## 🔄 Common Next Steps

### For Beginners
1. Explore component files
2. Change app title and colors
3. Add new symptoms
4. Modify risk calculation

### For Intermediate
1. Add form validation
2. Implement API integration
3. Add image analysis
4. Create result export

### For Advanced
1. Implement user authentication
2. Add database storage
3. Create ML model integration
4. Build admin dashboard

## 💡 Tips & Tricks

### Edit & Auto-Refresh
- Save file → Browser auto-refreshes
- No need to restart dev server
- Keep browser and editor visible

### Debug Console
- Open DevTools: F12 or Cmd+Option+I
- Check Console tab for errors
- Use React DevTools extension

### Mobile Testing
- Resize browser window
- Or use DevTools device emulator
- Test touch interactions

### Dark Mode Testing
- Click sun/moon in navbar
- Or use OS system preference
- Test with different themes

---

**You're all set! Happy coding! 🚀**

For more details, see [README.md](README.md) or [DEVELOPMENT.md](DEVELOPMENT.md).
