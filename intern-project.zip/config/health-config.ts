/**
 * Health Risk Predictor Configuration
 * 
 * Centralized configuration for the health prediction app.
 * Modify these values to customize the application behavior.
 */

/**
 * Risk Calculation Weights
 * Adjust these values to change how different factors affect risk calculation
 */
export const RISK_WEIGHTS = {
  BASE_RISK: 20,
  
  // Age factors (in percentage points)
  AGE_YOUNG: { threshold: 35, points: 0 },
  AGE_MIDDLE: { threshold: 45, points: 8 },
  AGE_MATURE: { threshold: 60, points: 15 },
  AGE_SENIOR: { threshold: 100, points: 25 },

  // BMI factors
  BMI_UNDERWEIGHT: { range: [0, 18.5], points: 0 },
  BMI_NORMAL: { range: [18.5, 25], points: 0 },
  BMI_OVERWEIGHT: { range: [25, 30], points: 10 },
  BMI_OBESE: { range: [30, 100], points: 20 },

  // Glucose level factors (mg/dL)
  GLUCOSE_NORMAL: { range: [0, 100], points: 0 },
  GLUCOSE_PREDIABETIC: { range: [100, 126], points: 15 },
  GLUCOSE_DIABETIC: { range: [126, 1000], points: 25 },

  // Blood pressure factors (systolic in mmHg)
  BP_NORMAL: { range: [0, 120], points: 0 },
  BP_ELEVATED: { range: [120, 130], points: 5 },
  BP_STAGE1: { range: [130, 140], points: 10 },
  BP_STAGE2: { range: [140, 200], points: 20 },

  // Lifestyle factors
  SMOKING: 15,
  ALCOHOL: 8,
  NO_EXERCISE: 12,

  // Symptoms
  SYMPTOM_WEIGHT: 5, // Points per symptom
  SYMPTOM_MAX: 25, // Maximum points from symptoms

  // Risk level thresholds
  RISK_LOW_THRESHOLD: 35,
  RISK_MEDIUM_THRESHOLD: 70,
}

/**
 * Predefined Symptoms List
 * Add or remove symptoms as needed
 */
export const COMMON_SYMPTOMS = [
  'Fever',
  'Headache',
  'Fatigue',
  'Chest Pain',
  'Shortness of Breath',
  'Cough',
  'Nausea',
  'Dizziness',
  'Body Aches',
  'Sore Throat',
  'Muscle Pain',
  'Joint Pain',
  'Rash',
  'Loss of Appetite',
  'Sweating',
]

/**
 * Condition Detection Rules
 * Configure thresholds for detecting specific conditions
 */
export const CONDITION_RULES = {
  DIABETES: {
    key: 'diabetes',
    name: 'Potential Diabetes',
    glucoseThreshold: 126,
    icon: 'AlertCircle',
  },
  OBESITY: {
    key: 'obesity',
    name: 'Obesity',
    bmiThreshold: 30,
    icon: 'AlertTriangle',
  },
  OVERWEIGHT: {
    key: 'overweight',
    name: 'Overweight',
    bmiThreshold: 25,
    icon: 'AlertTriangle',
  },
  HYPERTENSION_HIGH: {
    key: 'hypertension_high',
    name: 'Hypertension (High)',
    bpThreshold: 140,
    icon: 'AlertCircle',
  },
  HYPERTENSION_ELEVATED: {
    key: 'hypertension_elevated',
    name: 'Hypertension (Elevated)',
    bpThreshold: 130,
    icon: 'AlertTriangle',
  },
  CARDIOVASCULAR_RISK: {
    key: 'cardiovascular_risk',
    name: 'Possible Cardiovascular Risk',
    symptoms: ['Chest Pain', 'Shortness of Breath'],
    icon: 'AlertCircle',
  },
}

/**
 * Recommendation Templates
 * These are used to generate personalized recommendations
 */
export const RECOMMENDATIONS = {
  DIET: 'Consider a balanced diet and weight management program',
  EXERCISE: 'Increase physical activity to at least 150 minutes per week',
  SMOKING_CESSATION: 'Consult with a healthcare provider about smoking cessation programs',
  GLUCOSE_MONITORING: 'Monitor glucose levels and discuss diabetes prevention with your doctor',
  MEDICAL_CONSULTATION: 'Schedule a consultation with a healthcare professional',
  HEALTH_CHECKUP: 'Maintain regular health check-ups and screenings',
  BLOOD_PRESSURE: 'Monitor blood pressure regularly and consider lifestyle modifications',
  ALCOHOL_REDUCTION: 'Reduce alcohol consumption and discuss alternatives with your doctor',
  STRESS_MANAGEMENT: 'Practice stress management techniques such as meditation or yoga',
  SLEEP_QUALITY: 'Ensure adequate sleep (7-9 hours) and maintain consistent sleep schedule',
}

/**
 * Form Configuration
 */
export const FORM_CONFIG = {
  // Age constraints
  AGE_MIN: 0,
  AGE_MAX: 120,

  // Height constraints (in cm)
  HEIGHT_MIN: 50,
  HEIGHT_MAX: 250,

  // Weight constraints (in kg)
  WEIGHT_MIN: 20,
  WEIGHT_MAX: 500,

  // Heart rate constraints (bpm)
  HEART_RATE_MIN: 30,
  HEART_RATE_MAX: 200,

  // Glucose constraints (mg/dL)
  GLUCOSE_MIN: 40,
  GLUCOSE_MAX: 500,

  // File upload constraints
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_MIME_TYPES: ['image/jpeg', 'image/png'],
  ALLOWED_EXTENSIONS: ['jpg', 'jpeg', 'png'],
}

/**
 * UI Configuration
 */
export const UI_CONFIG = {
  // Animation delays (in ms)
  LOADING_DURATION: 1500,
  ANIMATION_DURATION: 300,

  // Toast notifications
  TOAST_DURATION: 3000,

  // Results auto-scroll delay
  SCROLL_DELAY: 100,

  // Theme colors (can be overridden in globals.css)
  PRIMARY_COLOR: '#3b82f6', // Blue
  SECONDARY_COLOR: '#10b981', // Green
  DESTRUCTIVE_COLOR: '#ef4444', // Red
}

/**
 * API Configuration
 */
export const API_CONFIG = {
  // API endpoint (set via environment variable or here)
  BASE_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000',

  // API timeout (in ms)
  TIMEOUT: 30000,

  // Retry configuration
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000,

  // Enable mock predictions for development
  USE_MOCK_API: process.env.NEXT_PUBLIC_USE_MOCK_API === 'true',
}

/**
 * Health Information Thresholds & Standards
 * Based on medical guidelines
 */
export const HEALTH_STANDARDS = {
  // BMI Categories
  BMI_CATEGORIES: {
    UNDERWEIGHT: { min: 0, max: 18.4, label: 'Underweight' },
    NORMAL: { min: 18.5, max: 24.9, label: 'Normal weight' },
    OVERWEIGHT: { min: 25, max: 29.9, label: 'Overweight' },
    OBESE: { min: 30, max: 999, label: 'Obese' },
  },

  // Blood Pressure Categories (systolic/diastolic)
  BLOOD_PRESSURE_CATEGORIES: {
    NORMAL: { label: 'Normal', systolic: [0, 120], diastolic: [0, 80] },
    ELEVATED: { label: 'Elevated', systolic: [120, 130], diastolic: [0, 80] },
    STAGE_1: { label: 'Stage 1 Hypertension', systolic: [130, 140], diastolic: [80, 90] },
    STAGE_2: { label: 'Stage 2 Hypertension', systolic: [140, 999], diastolic: [90, 999] },
  },

  // Glucose Levels (fasting, mg/dL)
  GLUCOSE_CATEGORIES: {
    NORMAL: { max: 99, label: 'Normal' },
    PREDIABETIC: { min: 100, max: 125, label: 'Prediabetic' },
    DIABETIC: { min: 126, label: 'Diabetic' },
  },

  // Resting Heart Rate Categories (bpm)
  HEART_RATE_CATEGORIES: {
    LOW: { max: 60, label: 'Low (Athletic)' },
    NORMAL: { min: 60, max: 100, label: 'Normal' },
    ELEVATED: { min: 100, max: 120, label: 'Elevated' },
    HIGH: { min: 120, label: 'High' },
  },
}

/**
 * Application Info
 */
export const APP_INFO = {
  NAME: 'HealthRisk AI',
  VERSION: '1.0.0',
  DESCRIPTION: 'AI-powered health risk prediction tool',
  AUTHOR: 'HealthRisk AI',
  REPO: 'https://github.com/healthrisk-ai/predictor',
  SUPPORT_EMAIL: 'support@healthrisk.ai',
}

/**
 * Feature Flags
 * Enable/disable features during development
 */
export const FEATURE_FLAGS = {
  ENABLE_IMAGE_ANALYSIS: false, // Set to true when backend is ready
  ENABLE_PDF_EXPORT: false,
  ENABLE_HISTORY: false,
  ENABLE_SHARING: false,
  ENABLE_NOTIFICATIONS: true,
  DEBUG_MODE: process.env.NODE_ENV === 'development',
}

/**
 * Helper function to get risk level color
 */
export function getRiskLevelColor(level: string): {
  bg: string
  text: string
  border: string
} {
  switch (level) {
    case 'Low':
      return {
        bg: 'bg-green-50 dark:bg-green-950',
        text: 'text-green-600 dark:text-green-400',
        border: 'border-green-200 dark:border-green-800',
      }
    case 'Medium':
      return {
        bg: 'bg-yellow-50 dark:bg-yellow-950',
        text: 'text-yellow-600 dark:text-yellow-400',
        border: 'border-yellow-200 dark:border-yellow-800',
      }
    case 'High':
      return {
        bg: 'bg-red-50 dark:bg-red-950',
        text: 'text-red-600 dark:text-red-400',
        border: 'border-red-200 dark:border-red-800',
      }
    default:
      return {
        bg: 'bg-gray-50 dark:bg-gray-950',
        text: 'text-gray-600 dark:text-gray-400',
        border: 'border-gray-200 dark:border-gray-800',
      }
  }
}
